﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Disparo_bala : MonoBehaviour {

    public float tiempo_destruccion_bala;
    public float Disparo_velocidad;
    private Vector3 Disparo_vec;

    // Use this for initialization
    void Start()
    {

        Disparo_vec = Vector3.right * Disparo_velocidad;

    }

    // Update is called once per frame
    void Update()
    {

        transform.Translate(Disparo_vec);
        Destroy(gameObject, tiempo_destruccion_bala);

    }

    void OnCollisionEnter(Collision col)
    {
        if (col.transform.tag != "Enemigo")
        {
            Destroy(col.gameObject);
        }

    }
}