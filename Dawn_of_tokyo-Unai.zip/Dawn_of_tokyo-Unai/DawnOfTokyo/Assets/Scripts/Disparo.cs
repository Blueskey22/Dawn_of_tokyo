﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Disparo : MonoBehaviour {

    public GameObject Disparo_obj;
    public Transform Disparo_pos;
    private float Disparo_delta = 0.5F;
    private float Siguiente_disparo = 1F;
    private float Mitiempo = 0.0F;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButtonDown("Fire1") )
        {
            //Siguiente_disparo = Mitiempo + Disparo_delta;
            Instantiate(Disparo_obj, Disparo_pos.position, Quaternion.identity);
            //Siguiente_disparo = Siguiente_disparo - Mitiempo;
            //Mitiempo = 0.0F;
        }

    }
}
